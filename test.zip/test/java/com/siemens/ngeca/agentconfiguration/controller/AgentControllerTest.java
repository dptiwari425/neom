package com.siemens.ngeca.agentconfiguration.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.siemens.ngeca.agentconfiguration.dto.AgentConfigurationDTO;
import com.siemens.ngeca.agentconfiguration.service.AgentService;
import com.siemens.ngeca.agentconfiguration.utils.AgentUtil;

@ActiveProfiles("test")
@WebMvcTest(controllers = AgentController.class)
class AgentControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AgentService agentService;
	

	//@Test
	void testGetAllAgent() throws Exception {

		List<AgentConfigurationDTO> confligurationList = new ArrayList<>();

		confligurationList.add(AgentUtil.getAgentConfigurationDTO());
		confligurationList.add(AgentUtil.getAgentConfigurationDTO());

		Mockito.doReturn(confligurationList).when(agentService).getAllAgent();

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/v1/agents/all");
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

	}

}