package com.siemens.ngeca.agentconfiguration.service;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.TextNode;
import com.siemens.ngeca.agentconfiguration.dto.Context;
import com.siemens.ngeca.agentconfiguration.entity.AgentConfiguration;
import com.siemens.ngeca.agentconfiguration.enums.AgentType;
import com.siemens.ngeca.agentconfiguration.service.impl.ResponseProcessorImpl;
import com.siemens.ngeca.agentconfiguration.utils.ContextUtils;

class ResponseProcessorTest {
	
	@Mock
	private ObjectMapper mapper;

	@InjectMocks
	private ResponseProcessor responseProcessor = new ResponseProcessorImpl();

	private static String responseFile ="[{\"deviceId\":\"SE14P0001\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":1.03,\"wd\":202,\"v2\":64.25,\"temp\":27.48,\"pr\":1011.55,\"p4\":30.5,\"p3\":3.15,\"p2\":18,\"p1\":5.25,\"lon\":34.9990913,\"lmin\":55,\"lmax\":81,\"leq\":70.48,\"lat\":28.12245817,\"hum\":39.1,\"g8\":6.42,\"g7\":0,\"g5\":0,\"g3\":89.31,\"g2\":0.25,\"g1\":475.5,\"bs\":100}},\"aqi\":110,\"aqiKey\":\"g3\",\"aqiMessage\":\"Moderate\"},{\"deviceId\":\"SE14P0002\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678796400,\"ws\":7.05,\"wd\":216,\"v2\":0,\"temp\":22.94,\"pr\":994.4,\"p4\":790.5,\"p3\":37.35,\"p2\":541.25,\"p1\":106.8,\"lon\":35.26144678,\"lmin\":83,\"lmax\":93,\"leq\":89.94,\"lat\":28.09935782,\"hum\":48.33,\"g8\":0,\"g7\":0,\"g5\":0,\"g3\":0,\"g2\":0.24,\"g1\":465.33,\"bs\":99.98}},\"aqi\":420,\"aqiKey\":\"p2\",\"aqiMessage\":\"Severe\"},{\"deviceId\":\"SE14P0003\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":2.28,\"wd\":216,\"v2\":0,\"temp\":28,\"pr\":1003.85,\"p4\":10.75,\"p3\":1.8,\"p2\":8,\"p1\":3.45,\"lon\":35.19526953,\"lmin\":45.9,\"lmax\":69,\"leq\":57.4,\"lat\":28.10634323,\"hum\":34.23,\"g8\":0,\"g7\":0,\"g5\":38.36,\"g3\":9.77,\"g2\":0.21,\"g1\":0}},\"aqi\":38,\"aqiKey\":\"g5\",\"aqiMessage\":\"Good\"},{\"deviceId\":\"SE14P0004\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":1.03,\"wd\":202,\"v2\":0,\"temp\":32.2,\"pr\":1011.87,\"p4\":16,\"p3\":1.4,\"p2\":12,\"p1\":4.2,\"lon\":34.9614924,\"lmin\":51,\"lmax\":71,\"leq\":58.26,\"lat\":28.12662923,\"hum\":32.81,\"g8\":0,\"g7\":0,\"g5\":24.48,\"g3\":89.33,\"g2\":0.18,\"g1\":438,\"bs\":99.98}},\"aqi\":110,\"aqiKey\":\"g3\",\"aqiMessage\":\"Moderate\"},{\"deviceId\":\"SE14P0005\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":2.28,\"wd\":216,\"v2\":0,\"temp\":27.69,\"pr\":1003.58,\"p4\":13.25,\"p3\":1.8,\"p2\":8.75,\"p1\":3.15,\"lon\":0,\"lmin\":46,\"lmax\":74,\"leq\":62.22,\"lat\":0,\"hum\":33.71,\"g8\":0,\"g7\":0,\"g5\":157.06,\"g3\":48.04,\"g1\":454,\"bs\":99.5}},\"aqi\":184,\"aqiKey\":\"g5\",\"aqiMessage\":\"Moderate\"}]";


	private static String filterResponse = "{\"deviceId\":\"[*].deviceId\",\"longnitude\":\"[*].payload.d.lon\",\"lattitude\":\"[*].payload.d.lat\"}";
	
	
	@BeforeEach
	public void init() {
		final Context context = new Context();

		AgentConfiguration agentConfiguration = new AgentConfiguration();
		agentConfiguration.setAgentResponse(filterResponse);
		agentConfiguration.setAgentType(AgentType.AQMESH);

		context.setAgentType(randomAlphabetic(10));
		context.setAgentConfiguration(agentConfiguration);

		ContextUtils.setContext(context);

		MockitoAnnotations.openMocks(this);

	}

	@Test
	void testReadValue() throws JsonProcessingException {

		JsonNode responseJson = new TextNode(responseFile);
		
		when(mapper.readTree(filterResponse)).thenReturn(responseJson);
		
		List<Map<String, Object>> token = responseProcessor.readValue(responseFile);

		assertNotNull(token);
	}

}
