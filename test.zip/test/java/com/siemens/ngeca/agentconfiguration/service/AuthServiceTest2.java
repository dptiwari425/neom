package com.siemens.ngeca.agentconfiguration.service;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.siemens.ngeca.agentconfiguration.dto.Context;
import com.siemens.ngeca.agentconfiguration.entity.AgentConfiguration;
import com.siemens.ngeca.agentconfiguration.enums.AgentType;
import com.siemens.ngeca.agentconfiguration.repository.AgentRepository;
import com.siemens.ngeca.agentconfiguration.service.impl.AuthServiceImpl;
import com.siemens.ngeca.agentconfiguration.utils.AgentServiceUtils;
import com.siemens.ngeca.agentconfiguration.utils.ContextUtils;

class AuthServiceTest2 {

	@Mock
	private RestTemplate restTemplate;

	@Mock
	AgentRepository agentRepository;
	
	@Mock
	private AgentServiceUtils agentServiceUtils;
	
	@InjectMocks
	private AuthService authService = new AuthServiceImpl();

	private static String agentRequest = "{\"Auth\":{\"http_method\":\"POST\",\"http_header\":[{\"key\":\"Content-Type\",\"value\":\"application/json\"}, {\"key\":\"user-agent\",\"value\":\"Application\"}],\"request_media_type\":\"APPLICATION_JSON\",\"request_body\":\"\\r\\n{\\r\\n\\\"scope\\\": \\\"view_data\\\",\\r\\n\\\"client_id\\\": \\\"7cadc10b-570f-45fd-b053-ca7f70586dce\\\",\\r\\n\\\"client_secret\\\": \\\"WFHZRIoO03ND24dfru9zT8mLKcQW8u1l\\\",\\r\\n\\\"grant_type\\\": \\\"client_credentials\\\"\\r\\n}\",\"url\":\"https://production.oizom.com/v1/oauth2/token\",\"query_params\":null,\"auth_type\":null,\"response_key_structure\":\"$.access_token\"},\"API\":[{\"http_method\":\"GET\",\"http_header\":[{\"key\":\"ClientId\",\"value\":\"7cadc10b-570f-45fd-b053-ca7f70586dce\"}, {\"key\":\"user-agent\",\"value\":\"Application\"}],\"request_media_type\":\"APPLICATION_JSON\",\"url\":\"https://production.oizom.com/v1/data/cur\",\"query_params\":null,\"auth_type\":null}]}";
	
	private static String responseToken = "{\"access_token\":\"token\",}";
	
	@BeforeEach
	public void init() {
		final Context context = new Context();

		AgentConfiguration agentConfiguration = new AgentConfiguration();
		agentConfiguration.setAgentRequest(agentRequest);
		agentConfiguration.setAgentType(AgentType.AQMESH);

		context.setAgentType(randomAlphabetic(10));
		context.setAgentConfiguration(agentConfiguration);

		ContextUtils.setContext(context);

		MockitoAnnotations.openMocks(this);

	}

	@Test
	void testGetToken() {
		
		ResponseEntity<String> myEntity = new ResponseEntity<String>(responseToken, HttpStatus.OK);

		when(restTemplate.exchange(ArgumentMatchers.any(String.class), ArgumentMatchers.any(HttpMethod.class),
				ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.<Class<String>>any())).thenReturn(myEntity);

		String token = authService.getToken();

		assertNotNull(token);
	}

	//@Test
	public void testGetTokenWhenConfigDoesNotExist() {
		HttpStatus status = null;
		AgentType agentType = AgentType.AQMESH;
		AgentConfiguration agentConfiguration = new AgentConfiguration();
		agentConfiguration.setAgentRequest(agentRequest);
		when(agentRepository.findAllByAgentType(agentType)).thenReturn(agentConfiguration);
		if(!agentConfiguration.getAgentRequest().isEmpty())
		{
			status = HttpStatus.OK;
		}
		assertNotEquals(status, HttpStatus.OK);
	}
}
