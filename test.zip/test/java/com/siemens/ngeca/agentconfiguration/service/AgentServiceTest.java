package com.siemens.ngeca.agentconfiguration.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.siemens.ngeca.agentconfiguration.dto.AgentConfigurationDTO;
import com.siemens.ngeca.agentconfiguration.entity.AgentConfiguration;
import com.siemens.ngeca.agentconfiguration.enums.AgentType;
import com.siemens.ngeca.agentconfiguration.repository.AgentRepository;
import com.siemens.ngeca.agentconfiguration.service.impl.AgentServiceImpl;
import com.siemens.ngeca.agentconfiguration.utils.AgentUtil;

class AgentServiceTest {

	@Mock
	private AgentRepository agentRepository;

	@InjectMocks
	AgentServiceImpl agentService = new AgentServiceImpl();
	
	
	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetAllAgent() {

		AgentConfiguration agentConfiguration = AgentUtil.getAgentConfiguration();

		when(agentRepository.findAll()).thenReturn(Arrays.asList(agentConfiguration));

		final List<AgentConfigurationDTO> result = agentService.getAllAgent();

		assertEquals(1,result.size());
	}

	@Test
	public void testGetAllAgentNull() {
		when(agentRepository.findAll()).thenReturn(Collections.emptyList());

		final List<AgentConfigurationDTO> result = agentService.getAllAgent();
		assertEquals(result, Collections.emptyList());

	}
	@Test
	public void testConvertEntityToDTO() {
		final AgentConfiguration agentConfiguration = new AgentConfiguration();
		final AgentConfigurationDTO expectedResult = new AgentConfigurationDTO();

		AgentConfiguration agentConfig = new AgentConfiguration();
		agentConfig.setAgentType(AgentType.AQMESH);
		agentConfig.setAgentRequest("agentRequest");
		expectedResult.setAgentRequest("agentRequest");
		expectedResult.setDevopsConfig("devopsConfig");

		final AgentConfigurationDTO result = agentService.convertEntityToDTO(agentConfig);
			assertNotNull(result);
	}
}
