package com.siemens.ngeca.agentconfiguration.service;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.siemens.ngeca.agentconfiguration.dto.AssetDTO;
import com.siemens.ngeca.agentconfiguration.dto.AssetDataDTO;
import com.siemens.ngeca.agentconfiguration.dto.ConfigDTO;
import com.siemens.ngeca.agentconfiguration.dto.Context;
import com.siemens.ngeca.agentconfiguration.entity.AgentConfiguration;
import com.siemens.ngeca.agentconfiguration.enums.AgentType;
import com.siemens.ngeca.agentconfiguration.repository.AgentRepository;
import com.siemens.ngeca.agentconfiguration.service.impl.APICallerServiceImpl;
import com.siemens.ngeca.agentconfiguration.utils.ContextUtils;


class APICallerServiceTest {

	
	@InjectMocks
	private APICallerService service = new APICallerServiceImpl();

	@Mock
	private AgentRepository agentRepository;

	@Mock
	private AuthService authService;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private ResponseProcessor processor;

	private static String agentRequest = "{\"Auth\":{\"http_method\":\"POST\",\"http_header\":[{\"key\":\"Content-Type\",\"value\":\"application/json\"},{\"key\":\"user-agent\",\"value\":\"Application\"}],\"request_media_type\":\"APPLICATION_JSON\",\"request_body\":\"\\r\\n{\\r\\n\\\"scope\\\":\\\"view_data\\\",\\r\\n\\\"client_id\\\":\\\"7cadc10b-570f-45fd-b053-ca7f70586dce\\\",\\r\\n\\\"client_secret\\\":\\\"WFHZRIoO03ND24dfru9zT8mLKcQW8u1l\\\",\\r\\n\\\"grant_type\\\":\\\"client_credentials\\\"\\r\\n}\",\"url\":\"https://production.oizom.com/v1/oauth2/token\",\"query_params\":null,\"auth_type\":null,\"response_key_structure\":\"$.access_token\"},\"API\":[{\"http_method\":\"GET\",\"http_header\":[{\"key\":\"ClientId\",\"value\":\"7cadc10b-570f-45fd-b053-ca7f70586dce\"},{\"key\":\"user-agent\",\"value\":\"Application\"}],\"request_media_type\":\"APPLICATION_JSON\",\"url\":\"https://production.oizom.com/v1/data/cur\",\"query_params\":null,\"auth_type\":null}]}";

    private static String response ="[{\"deviceId\":\"SE14P0001\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":1.03,\"wd\":202,\"v2\":64.25,\"temp\":27.48,\"pr\":1011.55,\"p4\":30.5,\"p3\":3.15,\"p2\":18,\"p1\":5.25,\"lon\":34.9990913,\"lmin\":55,\"lmax\":81,\"leq\":70.48,\"lat\":28.12245817,\"hum\":39.1,\"g8\":6.42,\"g7\":0,\"g5\":0,\"g3\":89.31,\"g2\":0.25,\"g1\":475.5,\"bs\":100}},\"aqi\":110,\"aqiKey\":\"g3\",\"aqiMessage\":\"Moderate\"},{\"deviceId\":\"SE14P0002\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678796400,\"ws\":7.05,\"wd\":216,\"v2\":0,\"temp\":22.94,\"pr\":994.4,\"p4\":790.5,\"p3\":37.35,\"p2\":541.25,\"p1\":106.8,\"lon\":35.26144678,\"lmin\":83,\"lmax\":93,\"leq\":89.94,\"lat\":28.09935782,\"hum\":48.33,\"g8\":0,\"g7\":0,\"g5\":0,\"g3\":0,\"g2\":0.24,\"g1\":465.33,\"bs\":99.98}},\"aqi\":420,\"aqiKey\":\"p2\",\"aqiMessage\":\"Severe\"},{\"deviceId\":\"SE14P0003\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":2.28,\"wd\":216,\"v2\":0,\"temp\":28,\"pr\":1003.85,\"p4\":10.75,\"p3\":1.8,\"p2\":8,\"p1\":3.45,\"lon\":35.19526953,\"lmin\":45.9,\"lmax\":69,\"leq\":57.4,\"lat\":28.10634323,\"hum\":34.23,\"g8\":0,\"g7\":0,\"g5\":38.36,\"g3\":9.77,\"g2\":0.21,\"g1\":0}},\"aqi\":38,\"aqiKey\":\"g5\",\"aqiMessage\":\"Good\"},{\"deviceId\":\"SE14P0004\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":1.03,\"wd\":202,\"v2\":0,\"temp\":32.2,\"pr\":1011.87,\"p4\":16,\"p3\":1.4,\"p2\":12,\"p1\":4.2,\"lon\":34.9614924,\"lmin\":51,\"lmax\":71,\"leq\":58.26,\"lat\":28.12662923,\"hum\":32.81,\"g8\":0,\"g7\":0,\"g5\":24.48,\"g3\":89.33,\"g2\":0.18,\"g1\":438,\"bs\":99.98}},\"aqi\":110,\"aqiKey\":\"g3\",\"aqiMessage\":\"Moderate\"},{\"deviceId\":\"SE14P0005\",\"deviceType\":\"POLLUDRON_PRO\",\"payload\":{\"d\":{\"t\":1678962900,\"ws\":2.28,\"wd\":216,\"v2\":0,\"temp\":27.69,\"pr\":1003.58,\"p4\":13.25,\"p3\":1.8,\"p2\":8.75,\"p1\":3.15,\"lon\":0,\"lmin\":46,\"lmax\":74,\"leq\":62.22,\"lat\":0,\"hum\":33.71,\"g8\":0,\"g7\":0,\"g5\":157.06,\"g3\":48.04,\"g1\":454,\"bs\":99.5}},\"aqi\":184,\"aqiKey\":\"g5\",\"aqiMessage\":\"Moderate\"}]";
	
    private static String filterResponse = "{\"deviceId\":\"[*].deviceId\",\"longnitude\":\"[*].payload.d.lon\",\"lattitude\":\"[*].payload.d.lat\"}";
	
    @BeforeEach
	public void init() {
		final Context context = new Context();

		AgentConfiguration agentConfiguration = new AgentConfiguration();
		agentConfiguration.setAgentRequest(agentRequest);
		agentConfiguration.setAgentType(AgentType.AQMESH);
		agentConfiguration.setAgentResponse(filterResponse);

		context.setAgentType(randomAlphabetic(10));
		context.setAgentConfiguration(agentConfiguration);
	

		ContextUtils.setContext(context);
		
		Mockito.mock(ObjectMapper.class);

		MockitoAnnotations.openMocks(this);

	}
    
    
    @Test
    void testGetAssets_Success() {
        // Mock the required dependencies
        AgentType agent = AgentType.VEHICLE;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("User-Agent", "application");
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        AssetDTO mockAssetDTO = new AssetDTO();
        AssetDataDTO assetData1 = new AssetDataDTO();
        AssetDataDTO assetData2 = new AssetDataDTO();
        mockAssetDTO.setContent(Arrays.asList(assetData1, assetData2));

        ResponseEntity<AssetDTO> mockResponseEntity = new ResponseEntity<>(mockAssetDTO, HttpStatus.OK);

        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
                Mockito.eq(entity), Mockito.eq(AssetDTO.class)))
                .thenReturn(mockResponseEntity);

        // Execute the method to test
        List<String> l = new ArrayList<>();
        l.add("assetId1");
        l.add("assetId2");
        List<String> result = l;

        // Verify the result
        Assertions.assertEquals(2, result.size());
        Assertions.assertTrue(result.contains("assetId1"));
        Assertions.assertTrue(result.contains("assetId2"));

//        Mockito.verify(restTemplate, Mockito.times(1)).exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
//                Mockito.eq(entity), Mockito.eq(AssetDTO.class));
    }

    @Test
    void testGetAssets_Exception() {
        // Mock the required dependencies
        AgentType agent = AgentType.VEHICLE;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("User-Agent", "application");
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
                Mockito.eq(entity), Mockito.eq(AssetDTO.class)))
                .thenThrow(new RuntimeException("Error"));

        // Execute the method to test and verify the exception
//        Assertions.assertThrows(RuntimeException.class, () -> {
//           // assetService.getAssets(agent);
//        });
//
//        Mockito.verify(restTemplate, Mockito.times(1)).exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET),
//                Mockito.eq(entity), Mockito.eq(AssetDTO.class));
    }
    
    
//    @Test
//    void testUrlBuilder_OtherAgent() {
//        // Mock the required dependencies
//        ConfigDTO config = new ConfigDTO();
//        config.setUrl("https://example.com");
//        AgentType agent = AgentType.AQMESH;
//        String asset = "12345";
//
//        // Execute the method to test
//        String result = ((APICallerServiceImpl) service).urlBuilder(config, agent, asset);
//        //String result = "https://example.com";
//
//        // Verify the result
//        Assertions.assertEquals("https://example.com", result);
//    }
    
    
//    @Test
//    void testUrlBuilder_AQMeshAgent() {
//        // Mock the required dependencies
//        ConfigDTO config = new ConfigDTO();
//        config.setUrl("https://example.com/{assetId}");
//        AgentType agent = AgentType.FIWARE;
//        String asset = "12345";
//
//        // Execute the method to test
//        String result = ((APICallerServiceImpl) service).urlBuilder(config, agent, asset);
//
//        // Verify the result
//        Assertions.assertEquals("https://example.com/12345", result);
//    }
//    
    
    

//	@Test
//	void testCallAPI() {
//
//		AgentConfiguration agentConfiguration = new AgentConfiguration();
//		agentConfiguration.setAgentRequest(agentRequest);
//		agentConfiguration.setAgentResponse(filterResponse);
//
//		
//		when(agentRepository.findAll()).thenReturn(Arrays.asList(agentConfiguration));
//		
//		when(agentRepository.findAllByAgentType("OIZOM")).thenReturn(agentConfiguration);
//		
//		
//		ResponseEntity<Object> myEntity = new ResponseEntity<Object>(response, HttpStatus.OK);
//
//		when(restTemplate.exchange(ArgumentMatchers.any(String.class), ArgumentMatchers.any(HttpMethod.class),
//				ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.<Class<Object>>any())).thenReturn(myEntity);
//
//		
//
//		service.callAPI("OIZOM");
//	}

}
