package com.siemens.ngeca.agentconfiguration.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;

/**
 * The Class AgentServiceUtilTest.
 * @author z004ehre
 */
class AgentServiceUtilTest {



	/** The agent service. */
	@InjectMocks
	AgentServiceUtils agentService = new AgentServiceUtils();
	
	
	/**
	 * Inits the.
	 */
	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}
	
	/**
	 * Test extract HTTP method get.
	 */
	@Test
    void testExtractHTTPMethod_Get() {
        // Execute the method to test
        HttpMethod result = agentService.extractHTTPMethod("GET");

        // Verify the result
        Assertions.assertEquals(HttpMethod.GET, result);
    }

    /**
     * Test extract HTTP method put.
     */
    @Test
    void testExtractHTTPMethod_Put() {
        // Execute the method to test
        HttpMethod result = agentService.extractHTTPMethod("PUT");

        // Verify the result
        Assertions.assertEquals(HttpMethod.PUT, result);
    }

    /**
     * Test extract HTTP method post.
     */
    @Test
    void testExtractHTTPMethod_Post() {
        // Execute the method to test
        HttpMethod result = agentService.extractHTTPMethod("POST");

        // Verify the result
        Assertions.assertEquals(HttpMethod.POST, result);
    }

    /**
     * Test extract HTTP method delete.
     */
    @Test
    void testExtractHTTPMethod_Delete() {
        // Execute the method to test
        HttpMethod result = agentService.extractHTTPMethod("DELETE");

        // Verify the result
        Assertions.assertEquals(HttpMethod.DELETE, result);
    }

    /**
     * Test extract HTTP method default.
     */
    @Test
    void testExtractHTTPMethod_Default() {
        // Execute the method to test
        HttpMethod result = agentService.extractHTTPMethod("HEAD");

        // Verify the result
        Assertions.assertEquals(HttpMethod.HEAD, result);
    }

    /**
     * Test extract HTTP method invalid.
     */
    @Test
    void testExtractHTTPMethod_Invalid() {
        // Execute the method to test
        HttpMethod result = agentService.extractHTTPMethod("INVALID");

        // Verify the result
        Assertions.assertEquals(HttpMethod.HEAD, result);
    }

}
