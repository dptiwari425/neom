package com.siemens.ngeca.agentconfiguration.utils;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

import com.siemens.ngeca.agentconfiguration.dto.AgentConfigurationDTO;
import com.siemens.ngeca.agentconfiguration.entity.AgentConfiguration;

public class AgentUtil {

	public static AgentConfigurationDTO getAgentConfigurationDTO() {
		AgentConfigurationDTO configuration = new AgentConfigurationDTO();
		configuration.setAgentRequest(randomAlphabetic(10));
		configuration.setDevopsConfig(randomAlphabetic(10));
		return configuration;
	}

	public static AgentConfiguration getAgentConfiguration() {
		AgentConfiguration configuration = new AgentConfiguration();
		configuration.setAgentRequest(randomAlphabetic(10));
		configuration.setDevopsConfig(randomAlphabetic(10));
		return configuration;

	}
}
